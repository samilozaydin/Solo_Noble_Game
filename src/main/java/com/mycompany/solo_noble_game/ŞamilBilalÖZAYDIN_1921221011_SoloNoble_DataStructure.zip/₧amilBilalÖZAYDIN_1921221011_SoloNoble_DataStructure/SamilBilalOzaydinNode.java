/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Solo_Noble;

import javax.swing.JButton;

/**
 *
 * @author Bilal
 */
public class SamilBilalOzaydinNode {
    private char word;
    private String num;
    private SamilBilalOzaydinNode next;
    private SamilBilalOzaydinNode child;
    private char peg;
    
    public SamilBilalOzaydinNode(char word,String num, char peg){
        this.num= num;
        this.word= word;
        this.peg= peg;
    }
    
    public SamilBilalOzaydinNode getNext (){
        return next;
    }
    public SamilBilalOzaydinNode getChild(){
        return child;
    }

    public char getWord() {
        return word;
    }

    public void setWord(char word) {
        this.word = word;
    }

    public String getNum() {
        return num;
    }

    public void setNum(String num) {
        this.num = num;
    }

    public void setNext(SamilBilalOzaydinNode next) {
        this.next = next;
    }

    public void setChild(SamilBilalOzaydinNode child) {
        this.child = child;
    }

    public char getPeg() {
        return peg;
    }

    public void setPeg(char peg) {
        this.peg = peg;
    }

    /**
     * @return the button
     */
   
}
