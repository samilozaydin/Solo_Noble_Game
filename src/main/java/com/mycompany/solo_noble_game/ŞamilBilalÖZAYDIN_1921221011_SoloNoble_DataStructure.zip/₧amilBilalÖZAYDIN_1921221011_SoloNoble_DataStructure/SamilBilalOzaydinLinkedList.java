/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Solo_Noble;

/**
 *
 * @author Bilal
 */
public class SamilBilalOzaydinLinkedList {

    private SamilBilalOzaydinNode head;
    private int dimension;

    public SamilBilalOzaydinLinkedList(char word, String num, char peg, int dimension) {
        this.head = new SamilBilalOzaydinNode(word, num, peg);
        this.dimension = dimension;
    }


    public SamilBilalOzaydinNode getHead() {
        return head;
    }

    public void setHead(SamilBilalOzaydinNode head) {
        this.head = head;
    }
}
